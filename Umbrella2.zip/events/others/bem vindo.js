const Discord = require("discord.js");
const client = require(`../../index.js`);
const { db, owner, tk } = require("../../database/index");

client.on("guildMemberAdd", (member) => {
    let canal_logs = "1271620923488735266";
    if (!canal_logs) return;
  
    const cor = db.get(`color_embed`)
    let embed = new Discord.EmbedBuilder()
    .setColor(cor)
    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
    .setImage("https://imgur.com/b635tia.gif")
    .setFooter({ text: `${member.guild.name}, ${member.user.id}`, icon_url: `${member.guild.iconURL({ dynamic: true })}`, })
    .setTitle(`🍓BEM VINDO(A)! ${member.user.displayName}`)
    .setDescription(`

        **EBAA mais um moranguinho(a) para turma! Para celebrarmos juntos lhe darei um desconto de 10% em todos os itens Pronto entrega pelas próximas 48 horas!!**

        **Não se esqueça de ler nossos <#1271620923488735269>**
        
        `);

    member.guild.channels.cache.get(canal_logs).send({ embeds: [embed], content: `${member}` }) // Caso queira que o usuário não seja mencionado, retire a parte do "content".
  })