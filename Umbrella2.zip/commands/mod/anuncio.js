// comandos/anunciar.js  (discord.js v14)
const {
    ApplicationCommandType,
    ApplicationCommandOptionType,
    PermissionFlagsBits,
    ChannelType,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ActionRowBuilder,
    EmbedBuilder,
  } = require('discord.js');
  
  const HEX_PADRAO        = '#8874ff';                       // cor padrão
  const SEPARADOR         = '━━━ ⋆★⋆ ━━━';                  // frufru visual
  const FIXED_THUMBNAIL   = 'https://imgur.com/VrBHzHH.png'; // thumbnail fixa
  
  module.exports = {
    name: 'anunciar',
    description: 'Cria um anúncio estilizado (thumbnail fixa + até 2 imagens extras).',
    type: ApplicationCommandType.ChatInput,
    options: [
      {
        name: 'chat',
        description: 'Canal onde o anúncio será postado',
        type: ApplicationCommandOptionType.Channel,
        required: true,
        channel_types: [ChannelType.GuildText],
      },
    ],
  
    /** @param {import('discord.js').ChatInputCommandInteraction} interaction */
    async run(client, interaction) {
      // 1) Permissão
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({
          content: '❌ Você precisa da permissão **Gerenciar Servidor**.',
          ephemeral: true,
        });
      }
  
      // 2) Modal
      const modal = new ModalBuilder()
        .setCustomId('anuncioModal')
        .setTitle('Novo anúncio');
  
      const campoTitulo = new TextInputBuilder()
        .setCustomId('titulo')
        .setLabel('Título')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Algo chamativo…')
        .setMaxLength(256)
        .setRequired(true);
  
      const campoDesc = new TextInputBuilder()
        .setCustomId('descricao')
        .setLabel('Descrição')
        .setStyle(TextInputStyle.Paragraph)
        .setPlaceholder('Detalhes do anúncio')
        .setRequired(true);
  
      const campoCor = new TextInputBuilder()
        .setCustomId('cor')
        .setLabel('Cor HEX (opcional)')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('#8874ff, #00ff00…')
        .setRequired(false);
  
      const campoImg1 = new TextInputBuilder()
        .setCustomId('img_url_1')
        .setLabel('URL da IMAGEM 1 (opcional)')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('https://exemplo.com/img1.png')
        .setRequired(false);
  
      const campoImg2 = new TextInputBuilder()
        .setCustomId('img_url_2')
        .setLabel('URL da IMAGEM 2 (opcional)')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('https://exemplo.com/img2.png')
        .setRequired(false);
  
      modal.addComponents(
        new ActionRowBuilder().addComponents(campoTitulo),
        new ActionRowBuilder().addComponents(campoDesc),
        new ActionRowBuilder().addComponents(campoCor),
        new ActionRowBuilder().addComponents(campoImg1),
        new ActionRowBuilder().addComponents(campoImg2),
      );
  
      await interaction.showModal(modal);
  
      // 3) Aguarda envio
      const envio = await interaction.awaitModalSubmit({
        filter: i => i.customId === 'anuncioModal' && i.user.id === interaction.user.id,
        time: 5 * 60 * 1000,
      }).catch(() => null);
  
      if (!envio) return; // tempo esgotado
  
      // 4) Dados
      const titulo    = envio.fields.getTextInputValue('titulo');
      const descricao = envio.fields.getTextInputValue('descricao');
      let   corInput  = envio.fields.getTextInputValue('cor')?.trim();
      const img1URL   = envio.fields.getTextInputValue('img_url_1')?.trim();
      const img2URL   = envio.fields.getTextInputValue('img_url_2')?.trim();
      const canalAlvo = interaction.options.getChannel('chat');
  
      // Cor válida?
      if (!/^#?([0-9A-F]{6})$/i.test(corInput || '')) corInput = HEX_PADRAO;
      if (!corInput.startsWith('#')) corInput = `#${corInput}`;
  
      // 5) Embed principal
      const embed = new EmbedBuilder()
        .setTitle(`✨ ${titulo}`)
        .setDescription(`${descricao}\n\n— *Equipe ${interaction.guild.name}*`)
        .setColor(corInput)
        .setAuthor({
          name: interaction.user.username,
          iconURL: interaction.user.displayAvatarURL({ size: 128 }),
        })
        .setThumbnail(FIXED_THUMBNAIL)          // thumbnail fixa
        .setFooter({
          text: `Enviado por ${interaction.user.tag}`,
          iconURL: interaction.user.displayAvatarURL(),
        })
        .setTimestamp()
        .addFields({ name: '\u200B', value: SEPARADOR });
  
      // 6) Envia embed
      await canalAlvo.send({ embeds: [embed] });
  
      // 7) Envia imagens extras fora da embed (se existirem)
      if (img1URL) await canalAlvo.send({ content: img1URL });
      if (img2URL) await canalAlvo.send({ content: img2URL });
  
      // 8) Confirma ao autor
      await envio.reply({ content: `✅ Anúncio e imagens enviados em ${canalAlvo}.`, ephemeral: true });
    },
  };
  